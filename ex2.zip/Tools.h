//
// Created by shulamit on 10/31/17.
//

#ifndef OTHELLO_TOOLS_H
#define OTHELLO_TOOLS_H

enum TokenValue {
    Black,
    White,
    Empty,
    NumTokenValues
};

class Tools {

};


#endif //OTHELLO_TOOLS_H
